## Web 

Forntend Application

### install the node packages for the web tier:
npm install

### start the app
npm start

###  NOTE this app uses two env variables:

- API_HOST: connection to backend
- PORT: Application port