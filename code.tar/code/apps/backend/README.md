# Demo 3tier app


### install the node packages for the api tier:
npm install

### start the app
npm start

###  NOTE this app uses two env variables:

- PORT: the listening PORT
- DB: the postgresql url to connect

